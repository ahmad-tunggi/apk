package com.example.apk.response;

import com.google.gson.annotations.SerializedName;

public class R_cek {
    @SerializedName("messages")
    private String messages;

    @SerializedName("status")
    private boolean status;

}
