package com.example.apk.model;

public class DataCek {
    private String kode;
}
