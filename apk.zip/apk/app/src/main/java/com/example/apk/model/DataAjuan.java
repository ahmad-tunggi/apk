package com.example.apk.model;

public class DataAjuan {
    private String kd_surat;
    private String nim;
    private String nama_lengkap;
    private String perihal;
    private String tujuan_surat;
    private String instansi;
    private String lokasi_penelitian;
    private String judul;

    public String getKd_surat() {
        return kd_surat;
    }

    public void setKd_surat(String kd_surat) {
        this.kd_surat = kd_surat;
    }



    public String getNim() {
        return nim;
    }

    public void setNim(String nim) {
        this.nim = nim;
    }

    public String getNama_lengkap() {
        return nama_lengkap;
    }

    public void setNama_lengkap(String nama_lengkap) {
        this.nama_lengkap = nama_lengkap;
    }

    public String getPerihal() {
        return perihal;
    }

    public void setPerihal(String perihal) {
        this.perihal = perihal;
    }

    public String getTujuan_surat() {
        return tujuan_surat;
    }

    public void setTujuan_surat(String tujuan_surat) {
        this.tujuan_surat = tujuan_surat;
    }

    public String getInstansi() {
        return instansi;
    }

    public void setInstansi(String instansi) {
        this.instansi = instansi;
    }

    public String getLokasi_penelitian() {
        return lokasi_penelitian;
    }

    public void setLokasi_penelitian(String lokasi_penelitian) {
        this.lokasi_penelitian = lokasi_penelitian;
    }

    public String getJudul() {
        return judul;
    }

    public void setJudul(String judul) {
        this.judul = judul;
    }
}
