package com.example.apk.utils;

public class Config {
//    public static final String BASE_URL = "  https://1345-36-85-221-134.ngrok-free.app/tugas_akhir/";
    public static final String BASE_URL = "    http://192.168.43.4/tugas_akhir/";

}
